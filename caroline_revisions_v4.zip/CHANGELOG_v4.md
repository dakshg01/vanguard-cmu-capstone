# Revision v4 (21 Nov 2026). Builds on v3 (CHANGELOG_v3.md). Deck NOT rebuilt yet.

## New since v3
1. Agency-MBS-in-corporate check. Vanguard Core (only fund with security-level holdings in the project): no material misclassification; mortgage-company bonds (Rocket, Freedom) are correctly corporate. About 0.1-0.2% of Vanguard Core is Freddie/Fannie credit-risk-transfer notes treated inconsistently (some agency via name fallback, some non-agency); immaterial. Competitor funds cannot be checked: raw N-PORT holdings are not in the project.
2. Unclassified holdings.
   - BlackRock Total Return filed one "Master Total Return Portfolio" line (100% of fund) through 2024-06; the look-through is the master fund's own filing, not available. From 2024-09 holdings are visible and classified (1.4-4.9% unresolved). Earlier quarters stay excluded.
   - Federated Hermes Total Return holds Federated Core Trust funds (Mortgage Core ~24%, Project & Trade Finance ~5%, High Yield ~5%, Bank Loan ~4%, money market). Mortgage Core, Project & Trade Finance and the unnamed core fund left unresolved (no data on their mix). Federated stays excluded (unresolved 42.2% -> 34.7%).
   - Reviewed overrides (inputs_optional/sector_overrides.csv, 218 fund-quarters): money-market funds -> cash; high-yield, bank-loan, floating-rate funds and corporate bond ETFs -> corporate; CLO ETFs -> ABS/CLO; EM local-currency funds -> EM. Net effect: 7 more fund-quarters pass the 10% screen (TCW MetWest 4, Goldman Sachs 3).
3. Model selection rule fixed in advance: OLS is the baseline; a nonlinear model replaces it only if its paired-bootstrap RMSE gain has a 95% interval excluding zero. Result: OLS selected (boosting 84.14 bp vs OLS 84.22 bp; all intervals include zero). Under the previous lowest-RMSE rule the 7 extra fund-quarters flipped the pick to boosting by 0.08 bp. See sponsor/model_selection_rule.csv.

## Effect on numbers (deck still shows pre-override values)
- ML: training rows 1,010 -> 1,013; model RMSEs shift by up to ~1.5 bp; conclusion unchanged (no gain over OLS).
- Vanguard residual (OLS), quarterly bp: Core 14.6, Core-Plus 6.3 (was 4.9), STAR -2.1. Under boosting, Core's residual is 0.5 bp, so the size of the residual depends on the model; keep that caveat on the residual slide.
- Band charts / Layer 2 peer ranges: small changes from 7 added fund-quarters.
- Benchmark-age sensitivity: usable fund-quarters 803 (0 days), 1,135 (45), 1,140 (100); results insensitive between 45 and 100 days.

## Still open
- Credit-quality ratings (factor 7) need Bloomberg data.
- Qiang: peer-median claim; 2022 agency MBS claim (MBB -11.7% vs SPAB -13.2%).
- Duration signs unverified.
- Mortgage-fund look-through (Federated, Fidelity Mortgage Central Fund) would need holdings of those underlying funds.
- Competitor agency-MBS check needs raw N-PORT holdings.
- Deck rebuild pending final approval of numbers.
