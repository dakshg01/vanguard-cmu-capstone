# Sponsor analysis, 15 November 2026

Use the sponsor/ tables and charts for the revised presentation. Earlier tables/ml_* outputs are retained as exploratory work and do not use the final competitor-only selection protocol.

1. Review coverage and return-class audit. The primary universe contains 49 funds. A fixed 2021–2025 window gives 47 comparable histories. Vanguard Core-Plus and STAR remain in all available-history exhibits.
2. Compare each Vanguard fund with same-style peers over precisely the same months. May 2026 is the latest common monthly endpoint across the established universe. Holdings snapshots extend to June. September filing dates do not establish Q3 holdings or return coverage.
3. Match each fund's holdings with the nearest earlier benchmark report within 100 days. Keep agency MBS separate. Corporate weights are not verified investment-grade weights. Screen unresolved holdings.
4. Regress monthly net excess returns on rate-level, curve, credit-spread and mortgage factors. Coefficient times realized factor movement gives additive model contributions. Residual alpha also contains omitted risks and measurement error.
5. Show March 2020 and April–December recovery separately. Refit the same 46 funds over September 2019–May 2026 with and without 2020. Calendar-aware HAC respects the missing year.
6. Examine fees using a cheapest-class proxy, style controls and HC3 uncertainty. Wide confidence intervals and class mismatch prevent a conclusion that fees do not matter.
7. Hold all Vanguard funds out of model selection. Compare OLS, elastic net, random forest and boosting on identical inputs. Tune inside whole-fund folds. Select using fund-equal RMSE, then check family, later-period and Vanguard holdouts. These use realized market shocks and explain outcomes retrospectively.
8. Treat report-date positions as observable for the explanatory study. This does not establish a feasible trading signal. Duration signs remain a normalized scenario, so the exploratory lead-yield association cannot support a trading recommendation.
9. Evaluate fund-level evidence of repeatability with multiple-testing and block-bootstrap checks. Individual manager tenure data are absent. Positive residuals alone do not establish skill.

Charts have PNG and SVG versions. All displayed numbers come from CSV tables. Competitor names are intended for the Vanguard audience only.
