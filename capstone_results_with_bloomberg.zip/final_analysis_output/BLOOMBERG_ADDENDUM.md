# Supplemental Bloomberg yield check

47 funds and 20 matching quarters. This is an appendix sensitivity check. The main monthly model uses the Fed zero-coupon yield curve. Alpha sign agreement: 100%. Median absolute annual alpha difference: 1.70 basis points.
