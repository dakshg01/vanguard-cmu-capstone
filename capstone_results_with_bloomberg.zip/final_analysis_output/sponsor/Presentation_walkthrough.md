# Presentation walkthrough

25 main slides, followed by seven appendix slides. Suggested five-speaker split: slides 1–5, 6–10, 11–16, 17–21 and 22–25. Allow roughly 8–9 minutes per speaker.

The notes explain the analysis, chart interpretation and limitations. The notebook is the computational source.

## Slide 1: Active bond funds
What competitors chose, and what paid

Opening, 1 minute. Introduce the question: what risk did active competitors choose relative to the benchmark, and did investors earn compensation after fees? State that this is an explanatory historical study, with evidence of repeatability distinguished from individual manager skill.

Source: CMU Team 006  •  Vanguard sponsor presentation  •  December 2, 2026

## Slide 2: Five sections connect positioning to performance

Roadmap, 1 minute. Suggested five-speaker handoffs: slides 1–5 context; 6–10 positioning; 11–16 performance; 17–21 methods; 22–25 implications. Each speaker has roughly 8–9 minutes. Appendix slides are for questions. The small footer highlights the current section.

Source: 45 minutes of presentation, followed by 15 minutes of discussion

## Slide 3: The analysis includes 49 funds and extends into 2026

Explain the sample, 2 minutes. There are 49 primary funds. Forty-seven have the complete 2021–2025 comparison window. The two shorter histories stay in available-history analysis and are not removed from the project. Monthly source returns extend into July for some funds; the complete common endpoint across established funds is May 2026. Holdings reach June 2026. September filing dates must not be mistaken for third-quarter report dates. SPAB is a broad aggregate bond ETF proxy, not every fund’s official benchmark. All performance is net of fees in the selected return series.

Source: Sources: coverage.csv; fund_scorecards.csv; source report and filing dates

## Slide 4: Two layers link active holdings to excess returns

Methods overview, 2 minutes. Layer 1 compares fund and benchmark positions. Report-date information is permitted for retrospective explanation. Starting holdings precede the return period. Layer 2 estimates joint return sensitivities to rate level, curve, credit and mortgage returns. Multiplying estimated loadings by realized factors gives additive contributions; an intercept remains. Sector weights alone are not rate risk: replacing Treasuries with corporates can keep duration similar. The intercept includes omitted risks and measurement error, so it is not proof of skill.

Source: Sources: quarterly_position_chart_panel.csv; monthly_factors.csv; factor_model_estimates.csv

## Slide 5: All three Vanguard funds beat their matched peer medians

Vanguard overview, 2 minutes. Compare each Vanguard fund with same-style competitors having every month of its own window through May 2026. The windows differ across rows, so do not rank the three Vanguard funds against one another using these values. Core starts July 2019 and has 10 complete peers. Core-Plus starts October 2021 with 26 peers. STAR starts March 2025 with 26 peers. Relative wealth is compound fund wealth divided by benchmark wealth minus one. STAR is a short descriptive history, not evidence of persistence.

Source: Source: sponsor/vanguard_comparable_windows.csv; relative wealth versus SPAB

## Slide 6: Corporate weights reveal active credit positioning

Positioning, roughly 1.5 minutes. The shaded band shows the 10th to 90th percentile of available Core competitors, with at least five funds per quarter. Counts change with coverage. Vanguard Core is red. Sector weights are normalized holdings weights in percentage points relative to the nearest earlier benchmark report, within 100 days. Unresolved holdings above the quality threshold are screened. Corporate issuers are not fully rated and cannot be described as IG-only. Duration is a dominant-sign normalized scenario, not independently validated duration, and is excluded from primary ML. Corporate weight does not measure credit quality or credit sensitivity.

Source: Source: sponsor/position_bands.csv; vanguard_positions.csv; Core peers

## Slide 7: Agency mortgages deserve a separate comparison

Positioning, roughly 1.5 minutes. The shaded band shows the 10th to 90th percentile of available Core competitors, with at least five funds per quarter. Counts change with coverage. Vanguard Core is red. Sector weights are normalized holdings weights in percentage points relative to the nearest earlier benchmark report, within 100 days. Unresolved holdings above the quality threshold are screened. Corporate issuers are not fully rated and cannot be described as IG-only. Duration is a dominant-sign normalized scenario, not independently validated duration, and is excluded from primary ML. Agency MBS stays separate. Early holdings classification may distort 2019 levels.

Source: Source: sponsor/position_bands.csv; vanguard_positions.csv; Core peers

## Slide 8: Other securitized holdings add a distinct source of risk

Positioning, roughly 1.5 minutes. The shaded band shows the 10th to 90th percentile of available Core competitors, with at least five funds per quarter. Counts change with coverage. Vanguard Core is red. Sector weights are normalized holdings weights in percentage points relative to the nearest earlier benchmark report, within 100 days. Unresolved holdings above the quality threshold are screened. Corporate issuers are not fully rated and cannot be described as IG-only. Duration is a dominant-sign normalized scenario, not independently validated duration, and is excluded from primary ML. Non-agency MBS, CMBS and ABS/CLO form this separate bucket.

Source: Source: sponsor/position_bands.csv; vanguard_positions.csv; Core peers

## Slide 9: Duration requires a risk measure beyond sector weights

Positioning, roughly 1.5 minutes. The shaded band shows the 10th to 90th percentile of available Core competitors, with at least five funds per quarter. Counts change with coverage. Vanguard Core is red. Sector weights are normalized holdings weights in percentage points relative to the nearest earlier benchmark report, within 100 days. Unresolved holdings above the quality threshold are screened. Corporate issuers are not fully rated and cannot be described as IG-only. Duration is a dominant-sign normalized scenario, not independently validated duration, and is excluded from primary ML. Exploratory sign-normalized scenario. Source signs remain unverified.

Source: Source: sponsor/position_bands.csv; vanguard_positions.csv; Core peers

## Slide 10: Vanguard Core gained relative wealth across a turbulent sample

Cumulative chart, 2 minutes. Ten Core peers have the complete same date window. The shaded range is a distribution of individual relative wealth paths, not the return of a tradable portfolio. Relative wealth compounds the fund return divided by SPAB return. Mark the March 2020 shock, 2022 rate cycle and March 2023 bank stress. June and July 2026 do not enter because a common endpoint is required.

Source: Source: sponsor/vanguard_relative_wealth.csv; July 2019–May 2026

## Slide 11: The share beating the benchmark changes sharply by year

Annual results, 1.5 minutes. Each full year requires twelve months and 2026 requires January–May. Count and percentage include all eligible primary funds with full coverage for the relevant year, including Vanguard. Different denominators mean this is not a fixed survival cohort. 2026 is partial and must not be compared with a full-year magnitude. The bars show net-of-fee benchmark wins, not statistically significant alpha.

Source: Source: annual net returns recalculated on complete calendar windows

## Slide 12: The COVID sell-off and recovery tell different stories

COVID, 3 minutes. Use relative wealth rather than annualizing a one-month event. Peer medians are same-style available funds with complete event coverage. March credit and liquidity stress hurt active peers, then the recovery rewarded their exposures. The same fund can look weak in March and strong over the calendar year. These descriptive results cannot isolate allocation, security selection and trading.

Source: Source: sponsor/stress_all_available.csv; March and April–December 2020

## Slide 13: Removing 2020 lowers the median estimated alpha

COVID sensitivity, 2 minutes. Exactly the same 46 funds have complete histories over the full window. Refit each regression after removing the twelve months of 2020. Factors, endpoint and all non-2020 dates stay fixed. Median alpha falls from about45 to25basis points per year. Counts of positive estimates are not counts of significant skill. Calendar-aware HAC does not treat December2019 and January2021 as adjacent months. Vanguard Core is shown separately; younger Vanguard funds do not have2020 histories.

Source: Source: sponsor/covid_matched_alpha.csv; 46 matched funds, September 2019–May 2026

## Slide 14: Vanguard Core’s alpha remains after modeled risk contributions

Risk attribution, 2 minutes. This is joint return-based factor attribution, the second layer requested by Qiang. The bars are annualized arithmetic contributions in basis points. Sum rate level, curve, credit, mortgage and intercept to recover average active return. Vanguard Core had a negative rate-level contribution, positive credit and mortgage contributions and a positive intercept. The intercept is conditional on this four-factor model. No security-level Brinson attribution or complete securitized-factor decomposition is claimed.

Source: Source: case_annualized_model_contributions_bp.csv; monthly model, 2021–2025

## Slide 15: Raw return rankings can change substantially after risk adjustment

Rankings, 2 minutes. Top and bottom raw relative-growth funds are shown alongside risk-adjusted ranks. Rankings are descriptive and are not evidence labels. Putnam moves dramatically after controlling for rate and mortgage factors. Rate and credit columns show estimated basis-point response to a100bpfall in the corresponding yield or spread, holding other factors fixed. Coefficients can be unstable. The main conclusion is that winners did not all use the same risk profile.

Source: Source: fund_scorecards.csv and common-window factor loadings; 2021–2025

## Slide 16: The fee data do not establish that fees are irrelevant

Fees, 3 minutes. The regression uses a median cheapest-class expense proxy, not verified fees for each return share class. The outcome is already net of fees. In the pooled regression with a Core-Plus indicator, a10bphigher proxy fee is associated with -3.7bpannualalpha, with95%CI about-19.4to12.0. The raw relative-growth slope is +1.8bp, CI-25.0to28.6. Neither rules out an economically relevant fee effect. Within-style estimates are also imprecise. Do not subtract fees again or describe this as contradicting the fee literature.

Source: Source: sponsor/fee_association.csv; 47 funds, 2021–2025, style-controlled HC3 OLS

## Slide 17: Vanguard stays outside every model-selection step

Explain the validation design. The training sample contains 1,010 fund-quarters from 44 competitors. All 46 Vanguard fund-quarters remain outside training and selection. The four models use the same 21 inputs, including active sector weights, realized market shocks, prespecified interactions, assets and style. Five outer whole-fund folds assess performance. Three inner folds tune parameters. Fund-equal RMSE determines the selected model. Family and later-period holdouts then assess stability. These are retrospective explanations, not return forecasts.

Source: Source: sponsor/summary.json; model_predictions.csv

## Slide 18: Boosting adds only a small gain over the OLS baseline

OLS is the baseline. Boosting wins under the prespecified fund-equal RMSE criterion, reducing error from 86.21 to 84.81 basis points, about 1.6%. Pooled RMSE improves by only 0.76%, from 80.84 to 80.22 basis points. The paired quarter-bootstrap interval for the pooled gain is −3.2% to +9.2%, so an improvement is uncertain. Random forest improves fund-equal error slightly but worsens pooled error. The evidence does not justify presenting machine learning as a major breakthrough.

Source: Source: sponsor/model_scores.csv; ml_gain_over_ols.csv; held-out competitor funds

## Slide 19: The explanatory fit weakens outside the competitor sample

The whole-fund validation shares calendar periods across training and test funds. That makes later-period and family checks valuable. Later-period models train before each test year from 2023 onward and still receive realized market shocks as inputs. Boosting has R² of −0.26 on later periods and −0.80 on Vanguard. Negative R² means greater squared error than the corresponding test sample's hindsight mean. OLS performs worse, but the result still limits confidence in transferability.

Source: Source: sponsor/model_scores.csv; R² on each held-out sample

## Slide 20: Vanguard’s model residuals do not establish manager skill

The model quarters differ from the monthly comparison windows because each row requires eligible starting holdings and a full following-quarter return. Vanguard Core contributes 26 quarters, Core-Plus 17 and STAR only 3. Boosting was selected before seeing Vanguard performance. Mean residuals of roughly 6 and 7 basis points for Core and Core-Plus are small relative to quarterly errors. STAR is too short for persistence claims. Random forest happens to perform slightly better on the Vanguard test set, but choosing it now would contaminate the test.

Source: Source: sponsor/vanguard_model_results.csv; selected boosting model

## Slide 21: Credit conditions help explain peer excess-return swings

The horizontal axis shows credit-spread tightening, defined as the negative change in Moody's BAA yield minus the 10-year Treasury yield. The vertical axis shows the monthly peer median net excess return. Positive x-values mean spreads tightened. This chart illustrates a relationship, while the joint regression also controls for rates, curve and mortgage returns. Available peer composition changes over time and extreme COVID observations can influence the relationship.

Source: Source: peer_credit_relationship.csv; monthly peer median, available funds

## Slide 22: Vanguard funds express different active sector choices

The table uses each Vanguard fund's latest eligible holdings snapshot and prints its report date. Corporate issuers are not fully rated. Other securitized combines non-agency MBS, CMBS and ABS/CLO. These are normalized sector weights relative to the benchmark and do not capture every derivative's economic exposure. Use same-style peers as context when interpreting different Vanguard mandates.

Source: Source: latest screened Vanguard holdings; nearest earlier benchmark report

## Slide 23: Three funds merit follow-up, with one clearing the strictest test

Bridge Builder Core-Plus, Bridge Builder Core and JPMorgan Core-Plus meet the configured positive-repeatability screen. Only Bridge Builder Core-Plus passes the stricter familywise max-t test at 5%. This is conditional evidence at fund level. It does not identify individual manager skill. No fund supports a negative-skill verdict under the same evidence standard. Inconclusive evidence is not evidence of no skill. Vanguard Core has a positive alpha estimate but falls short after multiple-testing adjustment.

Source: Source: fund_scorecards.csv; joint_zero_alpha_bootstrap.csv; 2021–2025

## Slide 24: The findings point to specific competitor research questions

For portfolio managers, compare credit and mortgage choices through both stress and recovery. The basic Treasury underweight is less informative by itself. For Vanguard, the matched-window peer comparisons are favorable, but the shorter histories and weak model transfer limit stronger claims. Research priorities are matched share-class fees, independently validated duration conventions and dated manager tenures. The exploratory duration-yield association is not statistically persuasive and remains in the appendix.

Source: Source: synthesis of positioning, stress, attribution and Vanguard holdouts

## Slide 25: Positioning explains part of performance, while skill remains a higher bar

Close with the evidence. Active positioning helps explain outcomes, and COVID materially changes the full-sample picture. All three Vanguard funds beat their matched peer medians. Machine learning adds little over OLS in competitor validation and transfers poorly. The fee data are too imprecise and imperfectly matched to establish no fee effect. Individual manager skill remains a higher evidentiary bar. Invite discussion of which competitor positions merit deeper investigation.

Source: Conclusions for Vanguard portfolio managers and researchers

## Slide 26: Peer duration offers no reliable yield-timing conclusion

This tests whether longer peer duration at quarter-end is associated with a fall in the 10-year yield during the next quarter. Report-date observability is allowed for this retrospective exercise. Across 28 quarters, the Core slope is approximately −58 basis points of yield change per year of active duration, with p=0.145. Core-Plus is approximately −27 with p=0.368. Both intervals include zero. Duration signs remain an unverified normalized scenario. Publication lags would matter for any later tradability claim. No reliable timing conclusion follows.

Source: Appendix A  •  sponsor/duration_yields.csv; duration_lead_association.csv

## Slide 27: Other stress periods expose different sources of active risk

These event comparisons use complete windows. Peer medians are calculated separately by style. Vanguard Core and Core-Plus have observations for both events; STAR does not. Relative wealth is not annualized. Use the contrasting 2022 and March 2023 outcomes to discuss why risk exposures can pay differently across regimes.

Source: Appendix B  •  sponsor/stress_all_available.csv

## Slide 28: Fee estimates remain imprecise within both styles

The table reports the association between a 10-basis-point higher cheapest-class fee proxy and annual factor alpha. Estimates remain imprecise within both styles. The Core sample contains 21 funds and Core-Plus 26. Share-class mismatch, risk differences and omitted characteristics prevent a causal interpretation. Net returns already include expenses, so fees should not be subtracted a second time.

Source: Appendix C  •  sponsor/fee_association.csv; HC3 confidence intervals

## Slide 29: Bloomberg yields provide an additional source check

The primary monthly yield source is the team's collected Federal Reserve zero-coupon Treasury curve. Bloomberg generic Treasury yields provide an optional quarterly sensitivity check. Their definitions differ. Source comparison uses matching quarters and aligned 10-year level and 10-year-minus-2-year curve factors. This supports source sensitivity analysis but does not replace the monthly main model. Bloomberg is a supporting appendix check rather than a central finding.

Source: Appendix D  •  bbg_quarterly_yield_comparison.csv; 2021–2025

## Slide 30: Coverage limits the precision of some comparisons

Unclassified holdings should not be forced into a convenient sector. TBAs, derivatives and issuer naming can create classification errors. The quality screen removes unreliable holdings snapshots, not entire funds from return analysis. No independently completed reclassification of the unresolved BlackRock and Federated holdings is claimed. The mortgage factor helps, but carry and other securitized risks remain incomplete. SPAB also differs from each fund's official benchmark.

Source: Appendix E  •  input audit, source tables and optional overrides

## Slide 31: Definitions keep the performance comparisons consistent

Relative wealth compounds fund wealth divided by benchmark wealth. Annual alpha is twelve times the monthly regression intercept and is not compounded. Tracking error is the standard deviation of monthly active return times the square root of twelve. Model RMSE is quarterly error in basis points. Every skill claim requires consideration of repeatability, omitted risks, uncertainty and source quality. The supplied universe may also be subject to selection and survivorship effects.

Source: Appendix F  •  notebook definitions and final sponsor README

## Slide 32: Vanguard combines low fee proxies with high reported turnover

Fees are cheapest-class proxies rather than verified selected-class expenses. Turnover is the reported accounting measure and can reflect mortgage roll activity. Medians use each fund’s available history, so this is descriptive rather than a matched-window causal comparison. STAR turnover is unavailable. Higher turnover alone does not establish higher realized trading costs.

Source: Appendix G  •  fund_scorecards.csv; available-history medians
