# Capstone analysis results
Generated 2026-11-15T02:50:48.270218+00:00

- Primary universe: 49 funds; 49 enter cleaned return analysis.
- 47 funds have a complete 2021–2025 selected-class return window.
- 1133 snapshots pass the provisional position/classification screen.
- Reference share-class choices are provisional unless verified overrides are supplied.
- Net fund returns are not reduced by expenses a second time. Gross-alpha claims require matched class fees.
- 5 main common-window alpha estimates pass the 5% FDR screen; consult the joint bootstrap and model sensitivity before interpreting this.
- 1 funds pass the 5% joint-bootstrap familywise max-t screen on the common window.
- Lowest held-out fund-equal explanatory RMSE: boosting, 78.4 bp per quarter. This is not forecasting performance.
- Later-period explanatory R-squared: -0.257; a negative value means the relationship did not generalize reliably across time.

## Open first
1. `presentation_report.html`: self-contained chart gallery, scorecards and limitations.
2. `tables/fund_scorecards.csv`: provisional evidence categories with uncertainty.
3. `tables/vanguard_scorecards.csv`: Vanguard comparison.
4. `charts/`: PNG for slides and SVG for editable figures.
5. `audit/limitations.csv`, `audit/reference_class_selection.csv`, `audit/validation_checks.csv`.

## Interpretation rules
- Alpha means residual performance conditional on the stated factors, not a direct measure of security selection.
- The representative class is chosen by coverage and ID, never by performance. Review flags exclude entire funds by default.
- Holdings benchmarks are nonfuture sampled ETF portfolios, not exact index constituents. Report freshness is visible.
- Duration-sign scenarios are not treated as verified exposures and are excluded from primary ML and skill labels.
- Monthly risk factors explain net active returns; their estimated contributions are not added to holdings-based contributions.
- The main credit proxy is BAA yield minus 10-year Treasury yield, not an exact credit total return. Mortgages and securitized coverage remain imperfect.
- The main model uses full available and ex-2020 samples; formal peer ranking uses complete 2021–2025 histories.
- Newey-West uncertainty respects calendar gaps; the common-window null bootstrap samples shared 6-month residual blocks across funds.
- ML has nested whole-fund validation, family validation and later-period explanatory tests. Realized shocks are not future information available to an investor.
- Latest amended disclosures and current adjusted-price histories support retrospective analysis. This is not a verified point-in-time investment backtest.
- There are only a small number of independent years/regimes; neither repeated fund observations nor flexible ML removes that limitation.
- Named results are for the sponsor audience. Use anonymous chart labels for external presentations; audit tables retain original IDs for reproducibility.


## Optional verified inputs
Put reviewed files in `inputs_optional/` and rerun the notebook. Templates describe required columns. Never overwrite generated tables by hand.
- `reference_classes.csv`: one class per fund, verified flag and source. Dated class switching is intentionally unsupported; use an uninterrupted reference class.
- `risk_sign_overrides.csv`: multiplier +1 or -1 converting signed reported sensitivity into economic duration, verified flag and source.
- `class_fees.csv`: selected class effective expense ratios in decimal units. Only this table supports expense add-back.
- `sector_overrides.csv`: normalized percentage-point transfers between existing sectors, with an auditable source.
- `benchmark_returns.csv`: monthly total returns in decimals, with source.
- `monthly_factors.csv`: decimal shocks/returns following the notebook's documented factor definitions, with source.
- `latest_issuer_ratings.csv`: optional descriptive issuer table; never used to fill historical ratings.

## Return to ChatGPT
Upload this results ZIP, or the executed notebook plus `tables/` and `audit/`. We can then review the actual estimates and turn supported findings into the final deck.
