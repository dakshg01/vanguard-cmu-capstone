"""
Fill each fund's stated prospectus benchmark (Qiang: "record each fund's own stated benchmark from its
prospectus"). Source: the same SEC Mutual Fund Prospectus Risk/Return Summary data sets as the fee panel.
The broad-based index in each fund's average-annual-returns table is tagged in num.tsv with a dimension
member naming the index (e.g. ...BloombergUSAggregateBondIndexMember).

Run on your Mac, from the sec_rr folder:
    cd ~/Downloads/vanguard-cmu-capstone-main/sec_rr
    python3 pull_benchmarks.py

Output: sec_rr/benchmarks/stated_benchmarks_raw.csv     every index member found, per fund and filing
        sec_rr/benchmarks/stated_benchmarks_latest.csv  latest filing's indices per fund (to review)
"""
import io, re, time, urllib.request, zipfile
from pathlib import Path
import pandas as pd

BASE = "https://www.sec.gov/files/dera/data/mutual-fund-prospectus-risk/return-summary-data-sets/{q}_rr1.zip"
USER_AGENT = "MSCF-Capstone research admin@example.com"
QUARTERS = [f"{y}q{q}" for y in (2023, 2024, 2025, 2026) for q in (1, 2, 3, 4)][:-2]   # 2023q1 .. 2026q2
HERE = Path(__file__).resolve().parent
RAW, OUT = HERE / "raw", HERE / "benchmarks"
UNIVERSE = HERE.parent / "universe.csv"

def fetch(q):
    path = RAW / f"{q}_rr1.zip"
    if path.exists() and zipfile.is_zipfile(path):
        return path
    print(f"  downloading {q} ...", flush=True)
    req = urllib.request.Request(BASE.format(q=q), headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=600) as r:
        path.write_bytes(r.read())
    time.sleep(0.5)
    return path

def readable(member):
    m = re.sub(r"^.*:", "", member)                      # drop namespace prefix
    m = re.sub(r"Member$", "", m)
    m = re.sub(r"([a-z])([A-Z])", r"\1 \2", m)
    m = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1 \2", m)
    m = re.sub(r"([A-Za-z])(\d)", r"\1 \2", m)
    return m.strip()

def main():
    RAW.mkdir(exist_ok=True); OUT.mkdir(exist_ok=True)
    uni = pd.read_csv(UNIVERSE, dtype=str, encoding="utf-8-sig")
    ids = set(uni.series_id)
    rows = []
    for q in QUARTERS:
        try:
            with zipfile.ZipFile(fetch(q)) as z:
                names = {Path(n).name.lower(): n for n in z.namelist()}
                num = pd.read_csv(z.open(names["num.tsv"]), sep="\t", dtype=str, keep_default_na=False, na_values=[""])
                sub = pd.read_csv(z.open(names["sub.tsv"]), sep="\t", dtype=str, keep_default_na=False, na_values=[""],
                                  usecols=lambda c: c in ("adsh", "name", "form", "filed"))
        except Exception as e:
            print(f"  {q}: FAILED ({e})"); continue
        perf = num[num["tag"].str.contains("AnnualReturn", case=False, na=False) & num["otherdims"].notna()]
        # series may be blank for index rows in newer filings; recover from other facts in the same filing
        if "series" in perf:
            filing_series = num.dropna(subset=["series"]).groupby("adsh")["series"].agg(lambda s: set(s))
            perf = perf.copy()
            perf["series_set"] = perf.apply(lambda r: {r["series"]} if pd.notna(r["series"]) else filing_series.get(r["adsh"], set()), axis=1)
            perf = perf.explode("series_set")
            perf = perf[perf["series_set"].isin(ids)]
        for _, r in perf.iterrows():
            for part in str(r["otherdims"]).split(";"):
                if "=" not in part: continue
                axis, member = part.split("=", 1)
                if re.search(r"index|benchmark|blend|composite", member, re.I):
                    rows.append(dict(dataset_quarter=q, adsh=r["adsh"], series_id=r["series_set"], axis=axis,
                                     member=member, index_name=readable(member)))
        print(f"  {q}: {len(rows)} index rows so far", flush=True)
    raw = pd.DataFrame(rows).drop_duplicates()
    if raw.empty:
        print("No index members found - send the terminal output to Claude."); return
    raw.to_csv(OUT / "stated_benchmarks_raw.csv", index=False)
    last_q = raw.groupby("series_id").dataset_quarter.max().rename("last_q")
    latest = raw.merge(last_q, on="series_id")
    latest = latest[latest.dataset_quarter == latest.last_q]
    latest = (latest.groupby("series_id").index_name.agg(lambda s: " | ".join(sorted(set(s))))
                    .rename("prospectus_indices_latest").reset_index())
    latest = uni[["series_id", "fund_name", "group", "nport_var_reference_index"]].merge(latest, on="series_id", how="left")
    latest.to_csv(OUT / "stated_benchmarks_latest.csv", index=False)
    print(latest[["fund_name", "prospectus_indices_latest"]].to_string(index=False))
    print("\nFunds with no index found:", latest.prospectus_indices_latest.isna().sum())

if __name__ == "__main__":
    main()
