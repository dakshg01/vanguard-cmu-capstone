# Data cleaning additions (Anna)

Copy everything in this folder into the repository root. Paths match the repo layout, so nothing existing is overwritten.

## What's here

| Path | What it is |
|---|---|
| `cleaned_data/` | **Final cleaned datasets from all five free sources**, with a README explaining every file, key and column |
| `data_sources/fred/` | Source 5: FRED credit spreads. Download script + outputs (24 series, daily and monthly) |
| `data_sources/fed_yield_curve/` | Source 4: Fed zero-coupon curve. Download script + outputs (3m–30y, daily and monthly) |
| `factor8_and_signs.py` | Factor 8 (rate/credit sensitivity from returns) and the DV01 sign check for all funds |
| `analysis/factor8_and_signs/` | Outputs of the script above |
| `sec_rr/pull_benchmarks.py` | Pulls each fund's stated prospectus benchmark from SEC filings (**not run yet**, see below) |

## How to rerun

```bash
# Source 5 and 4 (each needs internet access to fred.stlouisfed.org / federalreserve.gov)
python3 data_sources/fred/fetch_fred.py
python3 data_sources/fed_yield_curve/fetch_fed_curve.py

# Factor 8 + sign check (uses only CSVs already in the repo)
python3 factor8_and_signs.py
```

## Status

| Item | Status |
|---|---|
| Sources 1–2 N-PORT (run.py, analyze_sponsor.py) | Done (Daksh) |
| Source 3 fees (sec_rr/) | Done |
| Source 4 Fed curve | Done |
| Source 5 FRED | Done; ICE series start Oct 2023 (FRED keeps 3 years), Moody's covers 2019+ |
| DV01 sign check, swap currency conversion | Done |
| Merged fund-quarter panel (`cleaned_data/1_fund_quarter/master_fund_quarter_panel.csv`) | Done |
| Stated prospectus benchmark per fund | **Script ready, not run**: `cd sec_rr && python3 pull_benchmarks.py` on a machine that can reach sec.gov (~10–20 min) |
| Add funds that later closed or shrank | **Not run**: needs the raw SEC N-PORT ZIPs in `data/zips/` (not in the repo) |
| Bond ratings, IG/HY split, Factor 7 | Waiting for Bloomberg |
| Aggregate index analytics, fund inception dates | Waiting for Bloomberg |
| Columbia Total Return Bond risk filings | Flagged for review (filed 0.13 yrs vs ~7.6 implied by returns) |
