"""
Source 5: FRED credit spread series (credit factors) for the Vanguard / CMU capstone.

Run on your Mac (Terminal):
    cd ~/Downloads/fred_credit_spreads
    python3 fetch_fred.py                    # no key needed
    FRED_API_KEY=yourkey python3 fetch_fred.py   # optional, tries to recover pre-2023 ICE history

Output (in ./output):
    fred_credit_daily.csv        all series, daily, 2019-01-01 onward
    fred_credit_monthly.csv      month-end levels + monthly changes (the factor inputs)
    fred_credit_spreads.xlsx     the above + data dictionary + coverage sheet
    coverage_report.txt          first/last date and number of observations per series

Note: since April 2026 FRED only carries the most recent 3 years of the ICE BofA series.
The Moody's series (BAA10Y, AAA10Y) have full history and cover 2019 onward.
"""
import io, os, sys, time, urllib.request, urllib.parse, json
import pandas as pd

START = "2019-01-01"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
API_KEY = os.environ.get("FRED_API_KEY", "").strip()
VINTAGE = "2026-03-31"   # last vintage before FRED's 3-year cut for ICE series

SERIES = [
    # id, group, description, units
    ("BAMLC0A0CM",     "IG OAS",            "ICE BofA US Corporate (IG) OAS",               "% (spread)"),
    ("BAMLC0A1CAAA",   "IG OAS by rating",  "ICE BofA AAA US Corporate OAS",                "% (spread)"),
    ("BAMLC0A2CAA",    "IG OAS by rating",  "ICE BofA AA US Corporate OAS",                 "% (spread)"),
    ("BAMLC0A3CA",     "IG OAS by rating",  "ICE BofA Single-A US Corporate OAS",           "% (spread)"),
    ("BAMLC0A4CBBB",   "IG OAS by rating",  "ICE BofA BBB US Corporate OAS",                "% (spread)"),
    ("BAMLC1A0C13Y",   "IG OAS by maturity","ICE BofA 1-3Y US Corporate OAS",               "% (spread)"),
    ("BAMLC2A0C35Y",   "IG OAS by maturity","ICE BofA 3-5Y US Corporate OAS",               "% (spread)"),
    ("BAMLC3A0C57Y",   "IG OAS by maturity","ICE BofA 5-7Y US Corporate OAS",               "% (spread)"),
    ("BAMLC4A0C710Y",  "IG OAS by maturity","ICE BofA 7-10Y US Corporate OAS",              "% (spread)"),
    ("BAMLC7A0C1015Y", "IG OAS by maturity","ICE BofA 10-15Y US Corporate OAS",             "% (spread)"),
    ("BAMLC8A0C15PY",  "IG OAS by maturity","ICE BofA 15+Y US Corporate OAS",               "% (spread)"),
    ("BAMLH0A0HYM2",   "HY OAS",            "ICE BofA US High Yield OAS",                   "% (spread)"),
    ("BAMLH0A1HYBB",   "HY OAS by rating",  "ICE BofA BB US High Yield OAS",                "% (spread)"),
    ("BAMLH0A2HYB",    "HY OAS by rating",  "ICE BofA Single-B US High Yield OAS",          "% (spread)"),
    ("BAMLH0A3HYC",    "HY OAS by rating",  "ICE BofA CCC & Lower US High Yield OAS",       "% (spread)"),
    ("BAMLEMCBPIOAS",  "EM OAS",            "ICE BofA EM Corporate Plus OAS",               "% (spread)"),
    ("BAMLC0A0CMEY",   "Yields",            "ICE BofA US Corporate effective yield",        "% (yield)"),
    ("BAMLH0A0HYM2EY", "Yields",            "ICE BofA US High Yield effective yield",       "% (yield)"),
    ("BAMLCC0A0CMTRIV","Total return",      "ICE BofA US Corporate total return index",     "index level"),
    ("BAMLHYH0A0HYM2TRIV","Total return",   "ICE BofA US High Yield total return index",    "index level"),
    ("BAA10Y",         "Moody's spreads",   "Moody's Baa yield minus 10Y Treasury",         "% (spread)"),
    ("AAA10Y",         "Moody's spreads",   "Moody's Aaa yield minus 10Y Treasury",         "% (spread)"),
    ("DBAA",           "Moody's yields",    "Moody's seasoned Baa corporate yield",         "% (yield)"),
    ("DAAA",           "Moody's yields",    "Moody's seasoned Aaa corporate yield",         "% (yield)"),
]

def get(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (capstone research)"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read().decode()

def fetch_csv(sid):
    url = "https://fred.stlouisfed.org/graph/fredgraph.csv?" + urllib.parse.urlencode({"id": sid, "cosd": START})
    df = pd.read_csv(io.StringIO(get(url)))
    df.columns = ["date", sid]
    df["date"] = pd.to_datetime(df["date"])
    df[sid] = pd.to_numeric(df[sid], errors="coerce")   # FRED uses "." for missing
    return df.set_index("date")[sid]

def fetch_api(sid, vintage=None):
    p = {"series_id": sid, "api_key": API_KEY, "file_type": "json", "observation_start": START}
    if vintage:
        p.update(realtime_start=vintage, realtime_end=vintage)
    js = json.loads(get("https://api.stlouisfed.org/fred/series/observations?" + urllib.parse.urlencode(p)))
    obs = pd.DataFrame(js["observations"])
    s = pd.Series(pd.to_numeric(obs["value"], errors="coerce").values, index=pd.to_datetime(obs["date"]), name=sid)
    return s

def main():
    os.makedirs(OUT, exist_ok=True)
    data, notes = {}, {}
    for sid, *_ in SERIES:
        s, how = None, ""
        try:
            s = fetch_csv(sid); how = "fredgraph"
        except Exception as e:
            print(f"  {sid}: fredgraph failed ({e})")
        # try to recover longer history from an older vintage (needs a free API key)
        if API_KEY and sid.startswith("BAML"):
            try:
                v = fetch_api(sid, VINTAGE)
                if s is None or v.dropna().index.min() < s.dropna().index.min():
                    s = v.combine_first(s) if s is not None else v
                    how = f"API vintage {VINTAGE} + current"
            except Exception as e:
                print(f"  {sid}: vintage request failed ({e})")
        if s is None:
            notes[sid] = "FAILED"; continue
        data[sid] = s.rename(sid); notes[sid] = how
        d = s.dropna()
        print(f"{sid:20s} {d.index.min().date()} -> {d.index.max().date()}  n={len(d):5d}  [{how}]")
        time.sleep(0.5)

    daily = pd.concat(data.values(), axis=1).sort_index()
    daily = daily[daily.index >= START].dropna(how="all")
    daily.index.name = "date"

    # month-end levels (last available obs in month) and monthly changes
    lvl = daily.resample("ME").last()
    spread_cols = [c for c, g, *_ in SERIES if c in lvl and ("OAS" in g or "spreads" in g)]
    chg = lvl[spread_cols].diff().add_suffix("_chg")              # change in spread, pct pts
    tr_cols = [c for c, g, *_ in SERIES if c in lvl and g == "Total return"]
    ret = (lvl[tr_cols].pct_change() * 100).add_suffix("_ret")    # monthly total return, %
    monthly = pd.concat([lvl, chg, ret], axis=1)
    monthly.index.name = "month_end"

    meta = pd.DataFrame(SERIES, columns=["series_id", "group", "description", "units"])
    cov = []
    for sid in meta.series_id:
        d = daily[sid].dropna() if sid in daily else pd.Series(dtype=float)
        cov.append(dict(series_id=sid, first=d.index.min().date() if len(d) else None,
                        last=d.index.max().date() if len(d) else None, n_obs=len(d),
                        covers_2019=bool(len(d) and d.index.min() <= pd.Timestamp("2019-12-31")),
                        source=notes.get(sid, "")))
    cov = pd.DataFrame(cov)
    meta = meta.merge(cov, on="series_id")
    meta["fred_url"] = "https://fred.stlouisfed.org/series/" + meta.series_id

    daily.to_csv(os.path.join(OUT, "fred_credit_daily.csv"))
    monthly.to_csv(os.path.join(OUT, "fred_credit_monthly.csv"))
    meta.to_csv(os.path.join(OUT, "data_dictionary.csv"), index=False)
    try:
        with pd.ExcelWriter(os.path.join(OUT, "fred_credit_spreads.xlsx")) as xw:
            meta.to_excel(xw, sheet_name="README_dictionary", index=False)
            monthly.to_excel(xw, sheet_name="monthly")
            daily.to_excel(xw, sheet_name="daily")
    except ImportError:
        print("(openpyxl not installed: skipped xlsx, CSVs are written)")

    short = meta[~meta.covers_2019]
    with open(os.path.join(OUT, "coverage_report.txt"), "w") as f:
        f.write(meta[["series_id", "first", "last", "n_obs", "covers_2019", "source"]].to_string(index=False))
        f.write("\n\nSeries that do NOT reach back to 2019: " + (", ".join(short.series_id) or "none") + "\n")
    print("\nSeries not covering 2019:", ", ".join(short.series_id) or "none")
    print("Saved to", OUT)

if __name__ == "__main__":
    main()
