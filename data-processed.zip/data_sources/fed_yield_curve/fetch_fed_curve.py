"""
Source 4: Federal Reserve nominal Treasury zero-coupon yield curve (Gurkaynak, Sack & Wright)
Page: federalreserve.gov -> Data -> "The U.S. Treasury Yield Curve: 1961 to the Present"

Run on your Mac (Terminal):
    cd ~/Downloads/fed_yield_curve
    python3 fetch_fed_curve.py

Output (./output):
    fed_zero_curve_daily.csv      daily zero-coupon yields, 3m and 1-30 years, 2019 onward (%, cont. compounded)
    fed_zero_curve_monthly.csv    month-end yields + monthly changes (bp) + level/slope/curvature factors
    fed_yield_curve.xlsx          the above + README sheet
    coverage_report.txt
"""
import io, os, urllib.request
import numpy as np, pandas as pd

URL = "https://www.federalreserve.gov/data/yield-curve-tables/feds200628.csv"
START = "2019-01-01"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
KEY = [1, 2, 3, 5, 7, 10, 20, 30]      # years shown in the monthly file

def download():
    req = urllib.request.Request(URL, headers={"User-Agent": "Mozilla/5.0 (academic research)"})
    with urllib.request.urlopen(req, timeout=120) as r:
        return r.read().decode("utf-8", errors="replace")

def parse(text):
    lines = text.splitlines()
    start = next(i for i, l in enumerate(lines) if l.strip().strip('"').startswith("Date"))   # skip notes at top
    df = pd.read_csv(io.StringIO("\n".join(lines[start:])))
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).set_index("Date").sort_index()
    return df.apply(pd.to_numeric, errors="coerce")

def nss_yield(p, tau):
    """Svensson zero yield from the published parameters (used for the 3-month point)."""
    b0, b1, b2, b3, t1, t2 = (p[c] for c in ["BETA0", "BETA1", "BETA2", "BETA3", "TAU1", "TAU2"])
    x1, x2 = tau / t1, tau / t2
    f1 = (1 - np.exp(-x1)) / x1
    return b0 + b1 * f1 + b2 * (f1 - np.exp(-x1)) + b3 * ((1 - np.exp(-x2)) / x2 - np.exp(-x2))

def main():
    os.makedirs(OUT, exist_ok=True)
    raw = parse(download())
    raw = raw[raw.index >= START]
    zc = raw[[f"SVENY{n:02d}" for n in range(1, 31) if f"SVENY{n:02d}" in raw]].copy()
    zc.columns = [f"zc_{int(c[-2:])}y" for c in zc.columns]
    if {"BETA0", "TAU1"} <= set(raw.columns):
        zc.insert(0, "zc_3m", nss_yield(raw, 0.25))
    zc = zc.dropna(how="all"); zc.index.name = "date"

    m = zc.resample("ME").last()
    keep = ["zc_3m"] + [f"zc_{k}y" for k in KEY]
    keep = [c for c in keep if c in m]
    mon = m[keep].copy()
    chg = (m[keep].diff() * 100).add_suffix("_chg_bp")
    fac = pd.DataFrame(index=m.index)
    fac["level_avg_2_5_10y"] = m[["zc_2y", "zc_5y", "zc_10y"]].mean(axis=1)
    fac["slope_10y_minus_2y"] = m["zc_10y"] - m["zc_2y"]
    fac["slope_30y_minus_5y"] = m["zc_30y"] - m["zc_5y"]
    fac["curvature_2x5y_minus_2y_10y"] = 2 * m["zc_5y"] - m["zc_2y"] - m["zc_10y"]
    fac = pd.concat([fac, (fac.diff() * 100).add_suffix("_chg_bp")], axis=1)
    monthly = pd.concat([mon, chg, fac], axis=1); monthly.index.name = "month_end"

    zc.to_csv(os.path.join(OUT, "fed_zero_curve_daily.csv"))
    monthly.to_csv(os.path.join(OUT, "fed_zero_curve_monthly.csv"))
    readme = pd.DataFrame({"item": [
        "Source", "Units", "zc_Ny", "zc_3m", "*_chg_bp", "level / slope / curvature", "Note"], "description": [
        URL + " (Gurkaynak, Sack & Wright, Fed Board)",
        "Percent, continuously compounded zero-coupon yields",
        "Zero-coupon yield at N years (SVENYnn in the Fed file)",
        "3-month zero yield computed from the published Svensson parameters",
        "Month-end to month-end change in basis points (rate factors)",
        "level = mean(2y,5y,10y); slope = 10y-2y and 30y-5y; curvature = 2*5y-2y-10y",
        "Daily file has all tenors 1-30y; monthly file keeps the key tenors used for factors"]})
    try:
        with pd.ExcelWriter(os.path.join(OUT, "fed_yield_curve.xlsx")) as xw:
            readme.to_excel(xw, sheet_name="README", index=False)
            monthly.to_excel(xw, sheet_name="monthly")
            zc.to_excel(xw, sheet_name="daily")
    except ImportError:
        print("(openpyxl not installed: xlsx skipped, CSVs written)")

    rep = (f"Daily obs: {len(zc)}  from {zc.index.min().date()} to {zc.index.max().date()}\n"
           f"Tenors: {', '.join(zc.columns)}\nMonths: {len(monthly)}\n"
           f"Missing values (daily, any tenor): {int(zc.isna().sum().sum())}\n\n"
           f"Last month-end:\n{monthly[keep].tail(1).round(3).T.to_string()}\n")
    open(os.path.join(OUT, "coverage_report.txt"), "w").write(rep)
    print(rep); print("Saved to", OUT)

if __name__ == "__main__":
    main()
