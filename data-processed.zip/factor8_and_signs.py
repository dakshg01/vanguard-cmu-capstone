"""
Factor 8 (rates/credit hedging) + empirical check of the DV01 sign convention, for all 59 funds.

Run from the repository root (no database needed, only the committed CSVs):
    python3 factor8_and_signs.py

Inputs (repo):   output/csv/monthly_returns_latest.csv, output/csv/fund_quarter.csv,
                 fred_credit_monthly.csv, universe.csv, analysis/results/positioning_panel.csv
Input (Source 4): Fed zero-coupon curve, monthly (fed_zero_curve_monthly.csv)
Outputs:          analysis/factor8_and_signs/*.csv  (+ .xlsx if openpyxl is installed)

Method
  Rate factor   = month-end change in the Fed zero-coupon level, mean(2y, 5y, 10y), in bp
  Credit factor = month-end change in Moody's Baa - 10y Treasury spread (FRED BAA10Y), in bp
  r_fund,t = a + b_rate * d_rate_t + b_credit * d_credit_t + e_t   (36-month rolling window, min 24)
  Return-implied duration = -100 * b_rate (years), return-implied credit duration = -100 * b_credit
  Benchmark = SPDR Portfolio Aggregate (SPAB, S000017334), same proxy as analyze_sponsor.py

Reference share class: the class with the most clean monthly returns (ties: lowest class_id). Months in
overlapping fund/class/month groups are dropped entirely, as in analyze_sponsor.py. The choice is
written to reference_classes_used.csv so it can be replaced with a verified mapping.
"""
import argparse, os
import numpy as np, pandas as pd

BENCH = "S000017334"
WIN, MIN_OBS = 36, 24

def ols(y, X):
    return np.linalg.lstsq(X, y, rcond=None)[0]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fed", default="data_sources/fed_yield_curve/fed_zero_curve_monthly.csv")
    ap.add_argument("--out", default="analysis/factor8_and_signs")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    uni = pd.read_csv("universe.csv", dtype=str)

    # ---------------- factors
    fed = pd.read_csv(os.path.expanduser(a.fed), parse_dates=["month_end"]).set_index("month_end")
    fred = pd.read_csv("fred_credit_monthly.csv", parse_dates=["month_end"]).set_index("month_end")
    fac = pd.DataFrame({"d_rate_bp": fed["level_avg_2_5_10y_chg_bp"],
                        "d_credit_bp": fred["BAA10Y"].diff() * 100})
    fac.index = fac.index.to_period("M")
    fac = fac.dropna()

    # ---------------- monthly returns, one reference class per fund
    r = pd.read_csv("output/csv/monthly_returns_latest.csv", dtype={"class_id": str})
    r["class_id"] = r["class_id"].fillna("__NO_CLASS__")
    dup = r.duplicated(["series_id", "class_id", "month_end"], keep=False)
    r = r[~dup & r.return_pct.notna()].copy()
    r["month"] = pd.to_datetime(r.month_end).dt.to_period("M")
    cnt = r.groupby(["series_id", "class_id"]).month.nunique().reset_index(name="months")
    ref = cnt.sort_values(["series_id", "months", "class_id"], ascending=[True, False, True]).drop_duplicates("series_id")
    ref = ref.merge(cnt.groupby("series_id").size().rename("n_classes").reset_index(), on="series_id")
    ref.to_csv(f"{a.out}/reference_classes_used.csv", index=False)
    # fund-month return = median across share classes (robust to a single mis-reported class;
    # 4 funds fail the EDA class-consistency screen). Longest-history class kept for reference.
    rets = r.pivot_table(index="month", columns="series_id", values="return_pct", aggfunc="median").sort_index()
    rets.to_csv(f"{a.out}/fund_monthly_return_median_class.csv")
    bench = rets[BENCH]

    # ---------------- regressions
    full_rows, roll_rows = [], []
    for sid in rets.columns:
        df = pd.concat([rets[sid].rename("y"), bench.rename("b"), fac], axis=1).dropna()
        if len(df) < MIN_OBS:
            continue
        X = np.column_stack([np.ones(len(df)), df.d_rate_bp, df.d_credit_bp])
        bf, bb = ols(df.y.values, X), ols(df.b.values, X)
        resid = df.y.values - X @ bf
        r2 = 1 - resid.var() / df.y.values.var()
        full_rows.append(dict(series_id=sid, months=len(df), first=str(df.index.min()), last=str(df.index.max()),
                              implied_duration_yrs=-100 * bf[1], implied_credit_dur_yrs=-100 * bf[2],
                              bench_implied_duration_yrs=-100 * bb[1], bench_implied_credit_dur_yrs=-100 * bb[2],
                              alpha_pct_per_month=bf[0], r2=r2))
        for i in range(MIN_OBS - 1, len(df)):
            w = df.iloc[max(0, i - WIN + 1): i + 1]; Xw = X[max(0, i - WIN + 1): i + 1]
            f_, b_ = ols(w.y.values, Xw), ols(w.b.values, Xw)
            roll_rows.append(dict(series_id=sid, month=df.index[i], n_months=len(w),
                                  F8_rate_dur_yrs=-100 * f_[1], F8_credit_dur_yrs=-100 * f_[2],
                                  F8_bench_rate_dur_yrs=-100 * b_[1], F8_bench_credit_dur_yrs=-100 * b_[2]))
    full = pd.DataFrame(full_rows)
    roll = pd.DataFrame(roll_rows)
    roll["F8_active_rate_dur_yrs"] = roll.F8_rate_dur_yrs - roll.F8_bench_rate_dur_yrs
    roll["F8_active_credit_dur_yrs"] = roll.F8_credit_dur_yrs - roll.F8_bench_credit_dur_yrs

    # hedging summary: do active rate and active credit exposures offset each other over time?
    hedge = (roll.groupby("series_id")
                 .apply(lambda g: pd.Series({
                     "windows": len(g),
                     "mean_active_rate_dur": g.F8_active_rate_dur_yrs.mean(),
                     "mean_active_credit_dur": g.F8_active_credit_dur_yrs.mean(),
                     "corr_active_rate_vs_credit": g.F8_active_rate_dur_yrs.corr(g.F8_active_credit_dur_yrs)}),
                        include_groups=False).reset_index())
    hedge["hedge_pattern"] = np.where(
        (hedge.mean_active_credit_dur > 0.1) & (hedge.mean_active_rate_dur < -0.1), "long credit, short rates (offsetting)",
        np.where((hedge.mean_active_credit_dur > 0.1) & (hedge.mean_active_rate_dur > 0.1), "long credit and long rates",
        np.where(hedge.mean_active_credit_dur > 0.1, "long credit, rate-neutral", "no clear credit overweight")))

    # ---------------- sign convention, checked against returns
    fq = pd.read_csv("output/csv/fund_quarter.csv")
    fq["abs_rate"] = fq.usd_rate_sensitivity_years_signed.abs()
    conv = (fq.groupby("series_id")
              .agg(snapshots=("report_date", "size"),
                   filed_negative=("usd_rate_sensitivity_years_signed", lambda v: int((v < 0).sum())),
                   filed_positive=("usd_rate_sensitivity_years_signed", lambda v: int((v > 0).sum())),
                   median_abs_filed_dur=("abs_rate", "median"),
                   ig_sign_disagrees=("usd_rate_sensitivity_years_signed",
                                      lambda v: int((np.sign(v) != np.sign(fq.loc[v.index, "ig_spread_sensitivity_years_signed"]))
                                                    .where(fq.loc[v.index, "ig_spread_sensitivity_years_signed"].notna(), False).sum())))
              .reset_index())
    conv = conv.merge(full[["series_id", "implied_duration_yrs", "implied_credit_dur_yrs", "months", "r2"]], on="series_id", how="left")
    conv["convention"] = np.select([conv.filed_negative.eq(conv.snapshots), conv.filed_positive.eq(conv.snapshots)],
                                   ["value change (duration = -filed)", "magnitude (duration = +filed)"], "MIXED across filings")
    conv["filed_vs_return_gap_yrs"] = conv.median_abs_filed_dur - conv.implied_duration_yrs
    conv["verdict"] = np.select(
        [conv.implied_duration_yrs.isna(),
         conv.median_abs_filed_dur < 2,
         conv.filed_vs_return_gap_yrs.abs() > 2.0,
         conv.convention.str.startswith("MIXED")],
        ["no return history to check",
         "REVIEW: filed magnitude too small for a core fund",
         "REVIEW: filed duration far from return-implied",
         "OK magnitude, but sign convention switches over time"],
        "OK: |filed| consistent with returns")
    conv = uni[["series_id", "fund_name", "manager", "group"]].merge(conv, on="series_id", how="right")

    # economic (positive) duration: magnitude of filed value; flag rows that fail checks
    review = set(conv.loc[conv.verdict.str.startswith("REVIEW"), "series_id"])
    fq["usd_duration_econ_yrs"] = fq.abs_rate
    fq["ig_spread_dur_econ_yrs"] = fq.ig_spread_sensitivity_years_signed.abs()
    fq["hy_spread_dur_econ_yrs"] = fq.hy_spread_sensitivity_years_signed.abs()
    fq["econ_sign_flag"] = np.where(fq.series_id.isin(review), "fund flagged in sign_convention_check",
                           np.where(fq.abs_rate > 10, "magnitude > 10 yrs", "ok"))

    # ---------------- merge into the sponsor positioning panel
    p = pd.read_csv("analysis/results/positioning_panel.csv")
    key = fq[["series_id", "report_date", "usd_duration_econ_yrs", "ig_spread_dur_econ_yrs", "hy_spread_dur_econ_yrs", "econ_sign_flag"]]
    p = p.merge(key, on=["series_id", "report_date"], how="left")
    bkey = key.rename(columns={"series_id": "benchmark_series_id", "report_date": "benchmark_report_date",
                               "usd_duration_econ_yrs": "bench_usd_duration_econ_yrs", "ig_spread_dur_econ_yrs": "bench_ig_spread_dur_econ_yrs",
                               "hy_spread_dur_econ_yrs": "bench_hy_spread_dur_econ_yrs", "econ_sign_flag": "bench_econ_sign_flag"})
    p = p.merge(bkey, on=["benchmark_series_id", "benchmark_report_date"], how="left")
    p["F1_active_usd_duration_econ_yrs"] = p.usd_duration_econ_yrs - p.bench_usd_duration_econ_yrs
    p["F6_active_ig_spread_dur_econ_yrs"] = p.ig_spread_dur_econ_yrs - p.bench_ig_spread_dur_econ_yrs
    p["F6_active_hy_spread_dur_econ_yrs"] = p.hy_spread_dur_econ_yrs - p.bench_hy_spread_dur_econ_yrs
    p["month"] = pd.to_datetime(p.report_month).dt.to_period("M")
    p = p.merge(roll, on=["series_id", "month"], how="left").drop(columns="month")
    p["factor8_rate_credit_hedging"] = p["F8_active_rate_dur_yrs"].notna().map({True: "computed", False: "insufficient return history"})

    core_cols = (["series_id", "fund_name", "manager", "style", "report_date", "benchmark_proxy", "benchmark_report_date",
                  "sector_pair_complete", "econ_sign_flag"] +
                 [c for c in p.columns if c.startswith("active_sector_pp__")] + ["sector_reallocation_pct",
                 "usd_duration_econ_yrs", "bench_usd_duration_econ_yrs", "F1_active_usd_duration_econ_yrs",
                 "active_signed__curve_long_minus_short_signed",
                 "ig_spread_dur_econ_yrs", "F6_active_ig_spread_dur_econ_yrs", "F6_active_hy_spread_dur_econ_yrs",
                 "F8_rate_dur_yrs", "F8_credit_dur_yrs", "F8_active_rate_dur_yrs", "F8_active_credit_dur_yrs", "n_months"])
    core = p[core_cols].sort_values(["series_id", "report_date"])

    full = uni[["series_id", "fund_name", "group", "style"]].merge(full, on="series_id", how="right")
    hedge = uni[["series_id", "fund_name", "group", "style"]].merge(hedge, on="series_id", how="right")
    for name, d in [("CORE_panel_two_layers_plus_F8", core), ("positioning_panel_with_F8_and_econ_duration", p),
                    ("F8_full_period_by_fund", full), ("F8_rolling_36m", roll), ("F8_hedging_summary", hedge),
                    ("sign_convention_check", conv), ("factors_monthly", fac.reset_index())]:
        d.to_csv(f"{a.out}/{name}.csv", index=False)
    try:
        with pd.ExcelWriter(f"{a.out}/factor8_and_signs.xlsx") as xw:
            for name, d in [("CORE_panel", core), ("sign_convention_check", conv), ("F8_full_period", full),
                            ("F8_hedging_summary", hedge), ("F8_rolling_36m", roll), ("factors_monthly", fac.reset_index()),
                            ("reference_classes", ref)]:
                d.round(4).to_excel(xw, sheet_name=name[:31], index=False)
    except ImportError:
        print("openpyxl missing: CSVs only")

    pd.set_option("display.width", 220, "display.max_rows", 80)
    print(f"factor months: {fac.index.min()} to {fac.index.max()} ({len(fac)})")
    print(f"funds with F8: {full.series_id.nunique()}; rolling windows: {len(roll)}; panel rows with F8: {p.F8_rate_dur_yrs.notna().sum()} of {len(p)}")
    print("\nSign convention verdicts:\n", conv.verdict.value_counts().to_string())
    print("\nFlagged funds:\n", conv[~conv.verdict.str.startswith("OK")][["fund_name", "convention", "median_abs_filed_dur", "implied_duration_yrs", "verdict"]].round(2).to_string(index=False))
    print("\nCorrelation across funds, |filed| vs return-implied duration:",
          round(conv[["median_abs_filed_dur", "implied_duration_yrs"]].corr().iloc[0, 1], 3))
    prim = hedge[hedge.group == "PRIMARY"]
    print("\nHedging patterns (PRIMARY):\n", prim.hedge_pattern.value_counts().to_string())
    v = p[p.series_id == "S000053068"].tail(3)
    print("\nVCOBX last 3:\n", v[["report_date", "usd_duration_econ_yrs", "bench_usd_duration_econ_yrs", "F1_active_usd_duration_econ_yrs",
                                 "F6_active_ig_spread_dur_econ_yrs", "F8_rate_dur_yrs", "F8_active_rate_dur_yrs", "F8_active_credit_dur_yrs"]].round(2).to_string(index=False))
    print("\nsaved to", a.out)

if __name__ == "__main__":
    main()
