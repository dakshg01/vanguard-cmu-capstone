# Cleaned data: Vanguard / CMU capstone

Final cleaned datasets from all five free sources, ready for analysis. Bloomberg fields (bond ratings,
Aggregate index analytics, fund inception dates) will be added when that pull is complete.

**Universe:** 59 SEC series (49 primary, 4 benchmark index funds, 4 adjacent, 2 check), 2019-09 to 2026-07.

**Keys**
- Fund: `series_id` (SEC series ID). Never join on fund name.
- Fund-quarter: `series_id` + `report_date` (each fund's own fiscal quarter-end).
- Monthly data and factors: month-end date.

## 1_fund_quarter: one row per fund per report date

| File | Rows | What it is |
|---|---:|---|
| `master_fund_quarter_panel.csv` | 1,333 | **Main table.** Primary funds: active sector weights, active risk, fees, flows, size |
| `positioning_panel_full.csv` | 1,333 | Same funds with every intermediate column: fund and benchmark weights, raw and normalised, benchmark match details |
| `fund_quarter_filed.csv` | 1,577 | All 59 funds as filed: net assets, filing date and lag, delayed-delivery payables, risk in years (sign as filed) |
| `sector_weights.csv` | 1,577 | Sector weights for every fund and index fund, raw and normalised to 100% |
| `fees_panel.csv` | 3,220 | Fees per fund per calendar quarter, 2011Q1–2026Q2 (decimals: 0.0035 = 0.35%) |

Main columns in `master_fund_quarter_panel.csv`:

| Column | Meaning | Unit |
|---|---|---|
| `act_treasury` … `act_cash` | Fund minus benchmark sector weight | percentage points |
| `sector_active_share` | Half the sum of absolute sector differences | % |
| `act_duration_filed` | Active US duration from filed DV01, sign-checked | years |
| `curve_long_minus_short_signed` | Active (10y+30y) − (1y+5y) exposure, as filed | years |
| `act_ig_spread_dur_filed`, `act_hy_spread_dur_filed` | Active spread duration from filings, sign-checked | years |
| `F8_act_rate_dur_returns`, `F8_act_credit_dur_returns` | Active rate and credit sensitivity estimated from 36 months of returns | years |
| `net_exp_bp`, `turnover` | Net expense ratio (cheapest class), portfolio turnover | bp, decimal |
| `flow_3m_pct_nav` | Net external flow over the quarter ÷ previous net assets | % |
| `log_nav_bn` | log of net assets in $bn | |
| `benchmark_proxy`, `sector_pair_complete` | Index fund used as benchmark; whether both sides are complete | |
| `econ_sign_flag` | `ok`, or why the risk numbers need review | |

## 2_monthly: one row per month

| File | What it is |
|---|---|
| `fund_monthly_returns.csv` | Fund monthly return (%) = median across share classes; columns are series IDs |
| `share_class_monthly_returns.csv` | Every share class, as filed (overlapping months listed in review files) |
| `fund_monthly_flows.csv` | Sales, redemptions, reinvestment, net flows ($) |
| `rate_credit_sensitivity_rolling.csv` | 36-month rolling rate and credit sensitivity per fund and benchmark |

## 3_factors: market data

| File | What it is |
|---|---|
| `fed_zero_curve_daily.csv` / `_monthly.csv` | Fed zero-coupon yields 3m–30y (%), monthly changes (bp), level / slope / curvature |
| `fred_credit_daily.csv` / `_monthly.csv` | 24 FRED credit series; Moody's from 2019, ICE from Oct 2023 |
| `rate_credit_factors_monthly.csv` | The two factors used: change in curve level (bp) and in Moody's Baa spread (bp) |

## 4_reference

| File | What it is |
|---|---|
| `universe.csv` | Fund list with group, style, manager |
| `risk_sign_check.csv` | Filed DV01 sign convention per fund, checked against returns |
| `sector_classification_rules.csv` | How many holdings and how much weight each classification rule placed |
| `fred_series_dictionary.csv` | Description and coverage of each FRED series |

## Cleaning choices to know

- Latest filing kept when a report was amended. Month 1 is the oldest month of each quarter.
- Risk in years = DV01 × 10,000 ÷ net assets. Filers use different signs, so magnitudes are used, after checking each fund against its return-implied duration. Columbia Total Return Bond is flagged (filed 0.13 years vs about 7.6 from returns).
- Swap notionals converted to USD; interest rate swaps separated from credit default swaps.
- Sector weights include cash reported outside holdings and are normalised to 100%. IG and HY corporates are combined until ratings arrive.
- Benchmark: Aggregate index fund reporting in the same month (SPAB first, then AGG, SCHZ). No filling across months.
- Overlapping return months dropped. Four funds have a mis-reported share class, so fund returns use the median across classes.
- Fees use the latest prospectus filed by each quarter-end (no look-ahead).
